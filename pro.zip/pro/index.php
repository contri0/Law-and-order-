
<!DOCTYPE html>
<html lang="en-us">
<head>
    <title>Law-Order Automation</title>
    <link rel="shortcut icon" type="image/x-icon" href="images/lgo1.gif" />
  <!-- CSS -->
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" />
      <link rel="stylesheet" href="css/beta.css" />
      <link rel="stylesheet" href="css/button.css" />
      <link href="css/login1.css" rel="stylesheet">


</head>

<body onload="document.body.style.opacity='1'">
<div class="bg" id="bg"></div>
<div class="outer">


    <!-- Nav Bar -->
    <nav class="navbar navbar-default hidden-xs">
        <ul class="nav navbar-nav">
            <li>
                <a href="" class=" business_nav_link_class"><!-- Operator for Business --></a>
            </li>
            <li>
                <a href="" class="careers_nav_link_class"><!-- Careers --></a>
            </li>
            <li>
          
            </li>
        </ul>
    </nav>
    <br><br>


    <!-- Content -->

    <div class="container-fluid splashpage-root">
        <div class="row main-row">

            <div class="col-xs-12 col-sm-6" id=greetingContainer>
                <div class="greeting col-xs-12 col-lg-10">
                    <img class="hidden-xs" id="imgOperatorPeacock" style="width:59px" src="images/lgo1.gif">
                    <center><h2>Law and Order Automation</h2></center>
                </div>
            </div>

            <div class="col-xs-12 col-sm-6" id=screenshot-container>
                <div id=screenshot>
                    <img style="width:650px" src="images/law.jpg">
                </div>
            </div>



        </div>
    </div>
    <ul class="navigation">
    <a class="main" href="">Let me in</a>
    <li class="n1"><a href="#"" onclick="document.getElementById('modal-wrapper1').style.display='block'" >Citizen</a></li>
    <li class="n2"><a href="#" onclick="document.getElementById('modal-wrapper2').style.display='block'" ]>Administartor</a></li>
    <li class="n3"><a href="#" onclick="document.getElementById('modal-wrapper3').style.display='block'" >Police Officer</a></li>
    <li class="n4"><a href="#" onclick="document.getElementById('modal-wrapper4').style.display='block'" >Magistrate</a></li>
    </ul>

   <br>




         <div id="modal-wrapper1" class="modal1">
          <form class="modal-content animate" action="test.php" method="POST">

            <div class="imgcontainer">
              <img src="images/1.png" alt="Avatar" class="avatar">
              <h1 style="text-align:center">Welcome Citizen</h1>
            </div>

            <div class="container">
              <input type="text" placeholder="Enter Citizen_id" name="user"><br>
              <input type="password" placeholder="Enter Password" name="pass"><br>
              <input type="checkbox" style="margin:26px 30px;"> Remember me  <br>
              <button type="submit" name="submit1">Login</button><br>
              <input type="button" onclick="location.href='log1.php';" value="Sign up"/><br>
              <a href="#" class="forgot" >Forgot Password ?</a>


            </div>

          </form>

        </div>





        <div id="modal-wrapper2" class="modal2">
          <form class="modal-content animate" action="test.php" method="POST">

            <div class="imgcontainer">

              <img src="images/2.png" alt="Avatar" class="avatar">
              <h1 style="text-align:center">Welcome Administrator</h1>
            </div>

            <div class="container">
              <input type="text" placeholder="Enter Username" name="user"><br>
              <input type="password" placeholder="Enter Password" name="pass"><br>
              <input type="checkbox" style="margin:26px 30px;"> Remember me  <br>
              <button type="submit" name="submit2">Login</button><br>
              <a href="#" class="forgot">Forgot Password ?</a>


            </div>

          </form>

        </div>

        <div id="modal-wrapper3" class="modal3">
          <form class="modal-content animate" action="test.php" method="POST">

            <div class="imgcontainer">
               <img src="images/3.png" alt="Avatar" class="avatar">
              <h1 style="text-align:center">Welcome Police officer</h1>
            </div>

            <div class="container">
              <input type="text" placeholder="Enter Officer_id" name="user"><br>
              <input type="password" placeholder="Enter Password" name="pass"><br>
              <input type="checkbox" style="margin:26px 30px;"> Remember me  <br>
              <button type="submit" name="submit3">Login</button> <br>
              <a href="#" class="forgot">Forgot Password ?</a>


            </div>


          </form>


        </div>



         <div id="modal-wrapper4" class="modal4">
          <form class="modal-content animate" action="test.php" method="POST">

            <div class="imgcontainer">
              <img src="images/4.png" alt="Avatar" class="avatar">
              <h1 style="text-align:center">Welcome Magistrate</h1>
            </div>

            <div class="container">
              <input type="text" placeholder="Enter District" name="user1"><br>
              <input type="text" placeholder="Enter Name" name="user2"><br>
              <input type="password" placeholder="Enter Password" name="pass"><br>
              <input type="checkbox" style="margin:26px 30px;"> Remember me  <br>
              <button type="submit" name="submit4">Login</button><br>
              <a href="#" class="forgot">Forgot Password ?</a>


            </div>

          </form>

        </div>



<script>
// If user clicks anywhere outside of the modal, Modal will close

var modal1 = document.getElementById('modal-wrapper1');
var modal2 = document.getElementById('modal-wrapper2');
var modal3 = document.getElementById('modal-wrapper3');
var modal4 = document.getElementById('modal-wrapper4');
window.onclick = function(event) {
    if (event.target == modal1) {
        modal1.style.display = "none";
    }
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
    if (event.target == modal3) {
        modal3.style.display = "none";
    }
    if (event.target == modal4) {
        modal4.style.display = "none";
    }

}
</script>

</body>
</html>
